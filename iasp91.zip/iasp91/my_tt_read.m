function [OUT] = my_tt_read(filename)
% function [OUT] = my_tt_read(filename)


fid = fopen(filename,'r');

hdr = fgetl(fid);
tmp = fgetl(fid);
ndepth = sscanf(tmp,'%d');
depths = fscanf(fid,'%f',ndepth);
tmp = fgetl(fid);
tmp = fgetl(fid);
ndist = sscanf(tmp,'%d');
dist = fscanf(fid,'%f',ndist);
tmp = fgetl(fid);
tt = zeros(ndepth,ndist);
for k = 1:ndepth
    tmp = fgetl(fid);
    ttmp = fscanf(fid,'%f',ndist);
    tt(k,:) = ttmp;
    tmp = fgetl(fid);
end

OUT.tt = tt;
OUT.depths = depths;
OUT.dist = dist;

fclose(fid);

