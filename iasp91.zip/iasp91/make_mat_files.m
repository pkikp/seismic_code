%
close all
clear all

mkdir mat

tables = dir('tables/iasp91.*');

for k = 1:length(tables)
    
    PHASE = (tables(k).name);
    PHASE = strrep(PHASE,'iasp91.','');
    
    [TBL] = my_tt_read([tables.folder '/' tables(k).name])
    TBL.phase = PHASE;
    
    SYM = 'ko-';
    isp = strcmp(lower(PHASE(1)),'p');
    iss = strcmp(lower(PHASE(1)),'s');
    if( isp )
    SYM = 'b*-';
    end
    if( iss )
    SYM = 'ro-';
    end
    
    ttnot0 = TBL.tt(1,:) > 0 ;
    figure(1)
    plot(TBL.dist(ttnot0),TBL.tt(1,ttnot0),SYM);
    hold on
%     
%     figure(15)
%     plot(TBL.dist(ttnot0),TBL.tt(2,ttnot0),SYM);
%     hold on
%     
    
    
    save(['mat/' PHASE '.mat'],'TBL')
    
end
