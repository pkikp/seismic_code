close all
clear all
delta = [0:360];
depth = 33+0*delta;

LIST = dir('mat/*.mat');

for k = 1:length(LIST)
    phaselist(k) = strrep(string(LIST(k).name),'.mat','');
    tt = tt_iasp91(char( phaselist(k) ) , delta, depth );
    
    if( strfind( lower(phaselist(k)), 'p') == 1 )
        pc = 'b-';
    end
    if( strfind( lower(phaselist(k)), 's') == 1 )
        pc = 'r-';
    end
    if( strfind( phaselist(k), 'L') == 1 )
        pc = 'g-';
    end
    
    dtdd = zeros(size(tt));
    dtdd(2:end) = (tt(2:end)-tt(1:end-1))./ (delta(2:end)-delta(1:end-1));
    dtdd(1:end-1) = diff(tt) ./ diff(delta);
    valid = tt > 0 & abs(dtdd) < 30;
    figure(1)
    plot(delta(valid),tt(valid),pc)
    hold on
    figure(2)
    plot(delta(valid),dtdd(valid),pc)
    hold on
     phaselist(k)
     pause
end



